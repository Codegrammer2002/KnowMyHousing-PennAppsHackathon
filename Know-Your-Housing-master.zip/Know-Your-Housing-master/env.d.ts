declare namespace NodeJS {
  export interface ProcessEnv {
    NEXT_PUBLIC_GOOGLE_MAPS_API_KEY: string;
  }
}
